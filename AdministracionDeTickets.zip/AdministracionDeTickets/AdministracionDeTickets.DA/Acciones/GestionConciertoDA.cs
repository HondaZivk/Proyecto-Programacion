﻿

using AdministracionDeTickets.BC.Modelos;
using AdministracionDeTickets.BW.Interfaces.DA;
using AdministracionDeTickets.DA.Config;
using Microsoft.EntityFrameworkCore;

namespace AdministracionDeTickets.DA.Acciones
{
    public class GestionConciertoDA : IGestionDeConciertoDA
    {   
        private readonly GestionDeConciertoContext context;

        public GestionConciertoDA(GestionDeConciertoContext context)
        {
            this.context = context;
        }


        public async Task<bool> actualizarConcierto(int id, Concierto concierto, List<CategoriaAsiento> categoriasAsiento, List<MediaPromocional> media)
        {
            var mediasExistentes = await context.MediaPromocional
             .Where(media => media.IdConcierto == id)
             .ToListAsync();

            Concierto conciertoExistente = await context.Conciertos.FindAsync(id);

            if (conciertoExistente == null)
                return false;

            if (!conciertoExistente.InicioDeVenta)// Si la venta no se a inicio permite modificar todo
            {
                conciertoExistente.Nombre = concierto.Nombre;
                conciertoExistente.Descripcion = concierto.Descripcion;
                conciertoExistente.FechaHora = concierto.FechaHora;
                conciertoExistente.Lugar = concierto.Lugar;
                conciertoExistente.Capacidad = concierto.Capacidad;

                var categoriasExistentes = await context.CategoriaAsientos
                 .Where(categoria => categoria.IdConcierto == id)
                 .ToListAsync();

                context.CategoriaAsientos.RemoveRange(categoriasExistentes);

                foreach (var nuevaCategoria in categoriasAsiento)
                {
                    nuevaCategoria.IdConcierto = id;
                    context.CategoriaAsientos.Add(nuevaCategoria);
                }

            }
            else // Esto en el caso que la venta ya se inicio
            {
                conciertoExistente.Descripcion = concierto.Descripcion;
            }

            // En ambos casos se puede actualizar las medias
            context.MediaPromocional.RemoveRange(mediasExistentes);

            foreach (var nuevaMedia in media)
            {
                nuevaMedia.IdConcierto = id;
                context.MediaPromocional.Add(nuevaMedia);
            }

            await context.SaveChangesAsync();
            return true;
        }



        public async Task<bool> eliminarConcierto(int id)  // falta de hacer, siguiendo lo solicitado en el enunciado.
        {
            Concierto conciertoExistente = await context.Conciertos.FindAsync(id);
            if (conciertoExistente == null)
            {
                return false;
            }
            context.Conciertos.Remove(conciertoExistente);
            await context.SaveChangesAsync();
            return true;
        }

        public async Task<List<ResultadoFiltroConcierto>> obtenerCociertosPromotor(string correoPromotor)
        {
            var query = context.Conciertos.AsQueryable();

            if (!string.IsNullOrWhiteSpace(correoPromotor))
            {
                query = query.Where(concierto => !string.IsNullOrWhiteSpace(concierto.Promotor) && concierto.Promotor.Contains(correoPromotor));
            }

            var conciertosPromotor = await query.ToListAsync();

            var resultado = new List<ResultadoFiltroConcierto>();

            foreach (var concierto in conciertosPromotor)
            {
                var categorias = await context.CategoriaAsientos
                    .Where(cat => cat.IdConcierto == concierto.Id)
                      .Select(cat => new CategoriaAsiento
                      {
                          Id = cat.Id,
                          Nombre = cat.Nombre,
                          Numero = cat.Numero,
                          Precio = cat.Precio,
                          IdConcierto = cat.IdConcierto
                      }).ToListAsync();


                var media = await context.MediaPromocional
                 .Where(m => m.IdConcierto == concierto.Id)
                   .Select(m => new MediaPromocional
                   {
                       Id = m.Id,
                       FotoVideoUrl = m.FotoVideoUrl,
                       IdConcierto = m.IdConcierto
                   }).ToListAsync();

                var conciertoRespuesta = new Concierto
                {
                    Id = concierto.Id,
                    Nombre = concierto.Nombre,
                    Descripcion = concierto.Descripcion,
                    FechaHora = concierto.FechaHora,
                    Lugar = concierto.Lugar,
                    Capacidad = concierto.Capacidad,
                    InicioDeVenta = concierto.InicioDeVenta,
                    Promotor = concierto.Promotor,
                };

                resultado.Add(new ResultadoFiltroConcierto
                {
                    Concierto = conciertoRespuesta,
                    CategoriaAsientos = categorias,
                    MediaPromocional = media
                });
            }

            return resultado;
        }

        public async Task<List<ResultadoFiltroConcierto>> obtenerConciertos(DateTime? fecha, string lugar, string categoriaAsiento, string promotor)
        {
            var query = context.Conciertos.AsQueryable();

            if (fecha.HasValue)
            {
                query = query.Where(concierto => concierto.FechaHora.Date == fecha.Value.Date);
            }
          

            if (!string.IsNullOrWhiteSpace(lugar))
            {
                query = query.Where(concierto => concierto.Lugar.Contains(lugar));
            }
          

            if (!string.IsNullOrWhiteSpace(promotor))
            {
                // Validamos si existe ese correo en la tabla Usuarios con rol "Promotor"
                var existePromotor = await context.Usuarios
                    .AnyAsync(usuario => usuario.Correo == promotor && usuario.Rol.Trim().ToLower() == "promotor");

                // Si el promotor existe y tiene el rol adecuado, se filtran los conciertos para mostrar solo los del promotor especificado
                if (existePromotor)
                {
                    query = query.Where(concierto => concierto.Promotor == promotor); 
                }
              
            }

            if (!string.IsNullOrWhiteSpace(categoriaAsiento))
            {   // Se obtiene una lista de los IDs de conciertos que tienen al menos una categoría de asiento cuyo nombre contiene el texto ingresado
                var conciertoIds = await context.CategoriaAsientos
                    .Where(categoria => categoria.Nombre.Contains(categoriaAsiento))
                    .Select(categoria => categoria.IdConcierto)
                    .Distinct()
                    .ToListAsync();
                // Se actualiza la consulta principal para incluir solo los conciertos que están en la lista de IDs obtenida
                query = query.Where(concierto => conciertoIds.Contains(concierto.Id));
            }
            // Se ejecuta la consulta con todos los filtros aplicados y se obtiene la lista de conciertos filtrados
            var conciertosFiltrados = await query.ToListAsync();

            // Se prepara una nueva lista que contendrá los objetos de concierto completos (con sus categorías de asiento)
            var resultado = new List<ResultadoFiltroConcierto>();

            // Por cada concierto filtrado, se obtienen sus categorías de asiento y se agregan al objeto resultado
            foreach (var concierto in conciertosFiltrados)
            {
                var categorias = await context.CategoriaAsientos
                    .Where(cat => cat.IdConcierto == concierto.Id)
                      .Select(cat => new CategoriaAsiento
                      {
                          Id = cat.Id,
                          Nombre = cat.Nombre,
                          Numero = cat.Numero,
                          Precio = cat.Precio,
                          IdConcierto = cat.IdConcierto
                      }).ToListAsync();


                var media = await context.MediaPromocional
                 .Where(m => m.IdConcierto == concierto.Id)
                   .Select(m => new MediaPromocional
                   {
                       Id = m.Id,
                       FotoVideoUrl=m.FotoVideoUrl,
                       IdConcierto = m.IdConcierto
                   }).ToListAsync();

                var conciertoRespuesta = new Concierto
                {
                    Id = concierto.Id,
                    Nombre = concierto.Nombre,
                    Descripcion = concierto.Descripcion,
                    FechaHora = concierto.FechaHora,
                    Lugar = concierto.Lugar,
                    Capacidad = concierto.Capacidad,
                    InicioDeVenta = concierto.InicioDeVenta,
                    Promotor = concierto.Promotor,
                };

                resultado.Add(new ResultadoFiltroConcierto
                {
                    Concierto = conciertoRespuesta,
                    CategoriaAsientos = categorias,
                    MediaPromocional=media
                });
            }

            return resultado;
        }


    

        public async Task<bool> registrarConcierto(Concierto concierto ,List<CategoriaAsiento> categoriasAsiento, List<MediaPromocional> media)
        {
            try
            {
                context.Conciertos.Add(concierto);
                await context.SaveChangesAsync(); // Guardamos el id del concierto 

                foreach (var objetoMedia in media)
                {
                    objetoMedia.IdConcierto = concierto.Id;
                    context.MediaPromocional.Add(objetoMedia);
                }

                foreach (var asiento in categoriasAsiento)
                {
                    asiento.IdConcierto = concierto.Id;
                    context.CategoriaAsientos.Add(asiento);
                }
                

                await context.SaveChangesAsync();
                return true;
            }
            catch (Exception ex)
            {
                return false;

            }


        }

    }
}
