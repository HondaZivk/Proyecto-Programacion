﻿

using AdministracionDeTickets.BC.Modelos;
using AdministracionDeTickets.BW.CU;
using AdministracionDeTickets.BW.Interfaces.DA;
using AdministracionDeTickets.DA.Config;
using Microsoft.EntityFrameworkCore;


namespace AdministracionDeTickets.DA.Acciones
{
    public class GestionDeRolesDA : IGestionDeRolesDA
    {
        private readonly GestionDeConciertoContext context;
        public GestionDeRolesDA(GestionDeConciertoContext context)
        {
            this.context = context;
        }
       
        public async Task<bool> registrarUsuario(Usuario usuario)
        {
            try
            {
                // Verificar que el correo no esté ya registrado
                bool existe = await context.Usuarios.AnyAsync(u => u.Correo == usuario.Correo);

                if (existe)
                {
                    return false; 
                }
                usuario.Rol = "cliente";
                context.Usuarios.Add(usuario);
                await context.SaveChangesAsync();

                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error al registrar usuario: {ex.Message}");
                return false; 
            }
        }

        public async Task<Usuario?> obtenerUsuarioPorCredenciales(string correo, string contrasenia)
        {
            return await context.Usuarios
                .FirstOrDefaultAsync(usuario => usuario.Correo == correo && usuario.Contrasenia == contrasenia);
        }

        public async Task<bool> existeCorreo(string correo)
        {
            return await context.Usuarios.AnyAsync(usuarios => usuarios.Correo == correo);
        }
    }
}
