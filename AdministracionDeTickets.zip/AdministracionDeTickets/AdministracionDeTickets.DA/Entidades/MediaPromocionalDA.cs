﻿

using AdministracionDeTickets.BC.Modelos;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AdministracionDeTickets.DA.Entidades
{
    [Table("MediaPromocional")]
    public class MediaPromocionalDA
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        [Required]
        public string[] FotoVideoUrl { get; set; }

        [Required]
        public int IdConcierto { get; set; }
      
    }
}
