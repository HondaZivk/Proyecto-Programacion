﻿
using AdministracionDeTickets.BC.Modelos;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AdministracionDeTickets.DA.Entidades
{
    [Table("Conciertos")]
    public class ConciertoDA
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        [Required]
        [StringLength(100, MinimumLength = 5)]
        public string Nombre { get; set; }

        [Required]
        [MinLength(50)]
        public string Descripcion { get; set; }

        [Required]
        [DataType(DataType.DateTime)]
        public DateTime FechaHora { get; set; }

        [Required]
        [StringLength(100, MinimumLength = 5)]
        public string Lugar { get; set; }

        [Required]
        [Range(1, int.MaxValue, ErrorMessage = "La capacidad debe ser mayor que cero.")]
        public int Capacidad { get; set; }

        [Required]
        public Boolean InicioDeVenta { get; set; }

        
        [Required]
        [EmailAddress(ErrorMessage = "El promotor debe ser un correo electrónico válido")]
        public string Promotor { get; set; }



    }
}
