﻿

using AdministracionDeTickets.BC.Modelos;
using Microsoft.EntityFrameworkCore;


namespace AdministracionDeTickets.DA.Config
{
    public class GestionDeConciertoContext:DbContext
    {
        public GestionDeConciertoContext(DbContextOptions<GestionDeConciertoContext> options):base(options) { }

        public  DbSet<Concierto> Conciertos { get; set;}
        public DbSet<CategoriaAsiento> CategoriaAsientos { get; set;}

        public DbSet<MediaPromocional> MediaPromocional { get; set;}

        public DbSet<Usuario> Usuarios { get; set; }


    protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
             modelBuilder.Entity<CategoriaAsiento>()
               .HasOne<Concierto>()
               .WithMany()
               .HasForeignKey(ca => ca.IdConcierto)
               .OnDelete(DeleteBehavior.Cascade);

              modelBuilder.Entity<MediaPromocional>()
              .HasOne<Concierto>()
              .WithMany()
              .HasForeignKey(m => m.IdConcierto)
              .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<Usuario>()
            .HasKey(u => u.Correo);
        }

    }
}
