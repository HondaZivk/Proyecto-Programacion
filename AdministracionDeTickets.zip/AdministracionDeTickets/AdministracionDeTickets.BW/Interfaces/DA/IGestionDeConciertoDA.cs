﻿
using AdministracionDeTickets.BC.Modelos;

namespace AdministracionDeTickets.BW.Interfaces.DA
{
    public interface IGestionDeConciertoDA
    {
        Task<bool> registrarConcierto(Concierto concierto, List<CategoriaAsiento> categoriasAsiento, List<MediaPromocional> media);

        Task<bool> actualizarConcierto(int id, Concierto concierto, List<CategoriaAsiento> categoriasAsiento, List<MediaPromocional> media);

        Task<bool> eliminarConcierto(int id);

        Task<List<ResultadoFiltroConcierto>> obtenerConciertos(DateTime? fecha, string lugar, string categoriaAsiento, string promotor);

        Task<List<ResultadoFiltroConcierto>> obtenerCociertosPromotor(string correoPromotor);
    }
}
