﻿

using AdministracionDeTickets.BC.Modelos;

namespace AdministracionDeTickets.BW.Interfaces.DA
{
    public interface IGestionDeRolesDA
    {
        Task<bool> registrarUsuario(Usuario usuarios);
        Task<Usuario?> obtenerUsuarioPorCredenciales(string correo, string contrasenia);
        Task<bool> existeCorreo(string correo);
    }
}
