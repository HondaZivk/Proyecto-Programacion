﻿

using AdministracionDeTickets.BC.Modelos;

namespace AdministracionDeTickets.BW.Interfaces.BW
{
    public interface IGestionDeRolesBW
    {
        Task<bool> registrarUsuario(Usuario usuarios);
        Task<Usuario?> obtenerUsuarioPorCredenciales(string correo, string contrasenia);
        Task<bool> existeCorreo(string correo);
    }
}
