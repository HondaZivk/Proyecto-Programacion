﻿

using AdministracionDeTickets.BC.Modelos;

namespace AdministracionDeTickets.BW.Interfaces.BW
{
    public interface IGestionDeConciertoBW
    {
        Task<bool>registrarConcierto(Concierto concierto,List<CategoriaAsiento> categoriasAsiento, List<MediaPromocional> media); 

        Task<bool> actulizarConcierto(int id, Concierto concierto, List<CategoriaAsiento> categoriasAsiento, List<MediaPromocional> media);

        Task<bool> eliminarConcierto (int id);

        Task<List<ResultadoFiltroConcierto>> obtenerConciertos(DateTime? fecha, string lugar, string categoriaAsiento, string promotor);

        Task<List<ResultadoFiltroConcierto>> obtenerCociertosPromotor(string correoPromtor);
       
    }
}
