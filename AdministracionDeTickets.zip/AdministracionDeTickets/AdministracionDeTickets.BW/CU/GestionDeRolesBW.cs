﻿

using AdministracionDeTickets.BC.Modelos;
using AdministracionDeTickets.BC.ReglasDeNegocio;
using AdministracionDeTickets.BW.Interfaces.BW;
using AdministracionDeTickets.BW.Interfaces.DA;

namespace AdministracionDeTickets.BW.CU
{
    public class GestionDeRolesBW : IGestionDeRolesBW
    {
        private readonly IGestionDeRolesDA gestionDeRolesDA;

        public GestionDeRolesBW(IGestionDeRolesDA gestionDeRolesDA)
        {
            this.gestionDeRolesDA = gestionDeRolesDA;
        }


        public Task<Usuario?> obtenerUsuarioPorCredenciales(string correo, string contrasenia)
        {
            return gestionDeRolesDA.obtenerUsuarioPorCredenciales(correo, contrasenia);
        }

        public Task<bool> registrarUsuario(Usuario usuarios)
        {
            return ReglasDeUsuarios.elUsuarioEsValido(usuarios) ?
             gestionDeRolesDA.registrarUsuario(usuarios) :
             Task.FromResult(false);
        }

        public Task<bool> existeCorreo(string correo)
        {
            return gestionDeRolesDA.existeCorreo(correo);
        }
    }
}
