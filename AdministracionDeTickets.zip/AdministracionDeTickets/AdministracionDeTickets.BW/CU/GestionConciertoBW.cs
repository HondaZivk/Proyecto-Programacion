﻿

using AdministracionDeTickets.BC.Modelos;
using AdministracionDeTickets.BC.ReglasDeNegocio;
using AdministracionDeTickets.BW.Interfaces.BW;
using AdministracionDeTickets.BW.Interfaces.DA;

namespace AdministracionDeTickets.BW.CU
{
    public class GestionConciertoBW : IGestionDeConciertoBW
    {

        private readonly IGestionDeConciertoDA gestionDeConciertoDA;

        public GestionConciertoBW(IGestionDeConciertoDA gestionDeConciertoDA)
        {
            this.gestionDeConciertoDA = gestionDeConciertoDA;
        }
        public Task<bool> actulizarConcierto(int id, Concierto concierto, List<CategoriaAsiento> categoriasAsiento, List<MediaPromocional> media)
        {
            if (!ReglasDeConcierto.elIdEsValido(id) || !ReglasDeConcierto.actualizarConciertoEsValido(concierto, media))
            {
                return Task.FromResult(false);
            }
            return gestionDeConciertoDA.actualizarConcierto(id, concierto, categoriasAsiento, media);
        }

        public Task<bool> eliminarConcierto(int id)
        {
            return ReglasDeConcierto.elIdEsValido(id) ?
                gestionDeConciertoDA.eliminarConcierto(id) :
                Task.FromResult(false);
        }

        public Task<List<ResultadoFiltroConcierto>> obtenerCociertosPromotor(string correoPromtor)
        {
            return gestionDeConciertoDA.obtenerCociertosPromotor(correoPromtor);
        }

        public Task<List<ResultadoFiltroConcierto>> obtenerConciertos(DateTime? fecha, string lugar, string categoriaAsiento, string promotor)
        {
            return gestionDeConciertoDA.obtenerConciertos(fecha, lugar, categoriaAsiento, promotor);
        }



        public Task<bool> registrarConcierto(Concierto concierto, List<CategoriaAsiento> categoriasAsiento, List<MediaPromocional> media)
        {
            return ReglasDeConcierto.elConciertoEsValido(concierto, categoriasAsiento, media) ?
                gestionDeConciertoDA.registrarConcierto(concierto, categoriasAsiento, media) :
                Task.FromResult(false);
        }



       
    
    }
}
