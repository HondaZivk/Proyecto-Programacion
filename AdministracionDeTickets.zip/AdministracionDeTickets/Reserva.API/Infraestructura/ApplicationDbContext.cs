﻿using Microsoft.EntityFrameworkCore;
using Reserva.API.Entities;

namespace Reserva.API.Infrastructure
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options) { }

        public DbSet<Evento> Eventos => Set<Evento>();
        public DbSet<Sector> Sectors => Set<Sector>();
        public DbSet<Asiento> Asientos => Set<Asiento>();
        public DbSet<Reservacion> Reservaciones => Set<Reservacion>();

        // [Si usas ReservacionAsiento explícita]
        public DbSet<ReservacionAsiento> ReservacionAsientos => Set<ReservacionAsiento>();

        protected override void OnModelCreating(ModelBuilder b)
        {
            base.OnModelCreating(b);


            b.Entity<Evento>()
                .Property(e => e.Name).HasMaxLength(200).IsRequired();
            b.Entity<Evento>()
                .Property(e => e.Venue).HasMaxLength(200).IsRequired();

            b.Entity<Sector>()
                .HasOne(s => s.Evento)
                .WithMany(e => e.Sectors)
                .HasForeignKey(s => s.EventId)
                .OnDelete(DeleteBehavior.Restrict);

            b.Entity<Sector>()
                .HasIndex(s => new { s.EventId, s.Name }).IsUnique();

            b.Entity<Sector>()
                .Property(s => s.Price).HasColumnType("decimal(10,2)");


            b.Entity<Asiento>()
                .HasOne(a => a.Sector)
                .WithMany(s => s.Seats)
                .HasForeignKey(a => a.SectorId)
                .OnDelete(DeleteBehavior.Restrict);

            b.Entity<Asiento>()
                .HasIndex(a => new { a.SectorId, a.Label }).IsUnique();

            b.Entity<Asiento>()
                .Property(a => a.RowVersion).IsRowVersion();

            b.Entity<Reservacion>()
                .HasOne(r => r.Evento)
                .WithMany(e => e.Reservaciones)
                .HasForeignKey(r => r.EventId)
                .OnDelete(DeleteBehavior.Restrict);

            b.Entity<Reservacion>()
                .Property(r => r.UnitPrice).HasColumnType("decimal(10,2)");

            b.Entity<Reservacion>()
                .HasIndex(r => new { r.SessionKey, r.Status });

            b.Entity<ReservacionAsiento>()
                .HasOne(rs => rs.Reservacion)
                .WithMany(r => r.Seats)
                .HasForeignKey(rs => rs.ReservacionId)
                .OnDelete(DeleteBehavior.Cascade); // borrar detalle al borrar reserva

            b.Entity<ReservacionAsiento>()
                .HasOne(rs => rs.Asiento)
                .WithMany()                         // no exponemos colección en Asiento
                .HasForeignKey(rs => rs.AsientoId)
                .OnDelete(DeleteBehavior.Restrict); // evita multiple cascade paths

            b.Entity<ReservacionAsiento>()
                .HasIndex(rs => new { rs.ReservacionId, rs.AsientoId }).IsUnique();

        }
    }
}
