﻿using Reserva.API.Entities;

namespace Reserva.API.Infrastructure;

public static class DbSeeder
{
    public static async Task SeedAsync(ApplicationDbContext db)
    {
        if (db.Eventos.Any()) return;

        var ev = new Evento
        {
            Id = Guid.NewGuid(),
            Name = "Concierto Parque Viva",
            Venue = "Parque Viva",
            StartsAt = new DateTime(2025, 10, 5, 19, 0, 0)
        };

        var sectores = new[]
        {
            new Sector { Id=Guid.NewGuid(), Evento=ev, Name="ZonaVIP", Price=60000 },
            new Sector { Id=Guid.NewGuid(), Evento=ev, Name="ZonaGolden", Price=40000 },
            new Sector { Id=Guid.NewGuid(), Evento=ev, Name="Zona A", Price=25000 },
            new Sector { Id=Guid.NewGuid(), Evento=ev, Name="Zona B", Price=18000 },
        };

        foreach (var s in sectores)
        {
            for (int f = 1; f <= 6; f++)
                for (int c = 1; c <= 10; c++)
                {
                    var label = $"{(char)('A' + f - 1)}-{c:00}";
                    db.Asientos.Add(new Asiento
                    {
                        Id = Guid.NewGuid(),
                        Sector = s,
                        Label = label,
                        Status = AsientoStatus.Free
                    });
                }
        }

        await db.SaveChangesAsync();
    }
}
