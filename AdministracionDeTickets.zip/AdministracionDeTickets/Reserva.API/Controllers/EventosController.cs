﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Reserva.API.Infrastructure;

[ApiController]
[Route("api/[controller]")]
public class EventosController(ApplicationDbContext db) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> GetEventos()
        => Ok(await db.Eventos
            .Select(e => new { e.Id, e.Name, e.Venue, e.StartsAt })
            .ToListAsync());

    [HttpGet("{eventId:guid}/sectors")]
    public async Task<IActionResult> GetSectors(Guid eventId)
        => Ok(await db.Sectors
            .Where(s => s.EventId == eventId)
            .Select(s => new { s.Id, s.Name, s.Price })
            .ToListAsync());

    [HttpGet("{eventId:guid}/Asiento")]
    public async Task<IActionResult> GetSeats(Guid eventId, [FromQuery] string sector)
    {
        var data = await db.Asientos
            .Where(x => x.Sector.EventId == eventId && x.Sector.Name == sector)
            .Select(x => new { x.Id, x.Label, Status = x.Status.ToString() })
            .OrderBy(x => x.Label)
            .ToListAsync();

        return Ok(data);
    }
}
