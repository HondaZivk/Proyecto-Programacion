﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Reserva.API.Entities;
using Reserva.API.Infrastructure;
using static Reserva.API.DTOs.ReservacionDtos;

[ApiController]
[Route("api/[controller]")]
public class ReservacionesController(ApplicationDbContext db, IConfiguration cfg) : ControllerBase
{
    [HttpPost("hold")]
    public async Task<IActionResult> Hold([FromBody] HoldRequest req)
    {
        var ttlMinutes = cfg.GetValue<int>("HeldMinutes", 15);
        var now = DateTime.UtcNow;
        var expires = now.AddMinutes(ttlMinutes);

        // libera holds vencidos antes de intentar
        var expired = await db.Asientos.Where(s => s.Status == AsientoStatus.Held)
            .Join(db.ReservacionAsientos, s => s.Id, rs => rs.AsientoId, (s, rs) => new { s, rs })
            .Join(db.Reservaciones, x => x.rs.ReservacionId, r => r.Id, (x, r) => new { x.s, r })
            .Where(x => x.r.Status == ReservationStatus.Held && x.r.HeldUntil < now)
            .Select(x => x.s).ToListAsync();

        foreach (var s in expired) s.Status = AsientoStatus.Free;
        await db.SaveChangesAsync();

        // localizar sector
        var sector = await db.Sectors.Include(s => s.Seats)
            .FirstOrDefaultAsync(s => s.EventId == req.EventId && s.Name == req.Sector);
        if (sector is null) return NotFound("Sector no encontrado.");

        // asientos por label solicitados
        var seatsMap = sector.Seats
            .Where(s => req.Labels.Contains(s.Label))
            .ToDictionary(s => s.Label, s => s);

        var held = new List<string>();
        var failed = new List<string>();

        using var tx = await db.Database.BeginTransactionAsync();

        foreach (var label in req.Labels)
        {
            if (!seatsMap.TryGetValue(label, out var seat)) { failed.Add(label); continue; }

            // Intentar hold solo si está libre
            if (seat.Status == AsientoStatus.Free)
            {
                seat.Status = AsientoStatus.Held;
                held.Add(label);
            }
            else failed.Add(label);
        }

        if (held.Count > 0)
        {
            var res = new Reservacion
            {
                Id = Guid.NewGuid(),
                EventId = req.EventId,
                SectorName = req.Sector,
                UnitPrice = req.UnitPrice,
                SessionKey = req.SessionKey,
                HeldUntil = expires,
                Status = ReservationStatus.Held
            };
            db.Reservaciones.Add(res);

            foreach (var h in held)
            {
                var seat = seatsMap[h];
                db.ReservacionAsientos.Add(new ReservacionAsiento { Id = Guid.NewGuid(), Reservacion = res, Asiento = seat });
            }

            await db.SaveChangesAsync();
            await tx.CommitAsync();

            return Ok(new { ReservationId = res.Id, Held = held, Failed = failed });
        }
        else
        {
            await tx.RollbackAsync();
            return Ok(new { ReservationId = (Guid?)null, Held = held, Failed = failed });
        }
    }

    [HttpPost("confirm")]
    public async Task<IActionResult> Confirm([FromBody] ConfirmRequest req)
    {
        var now = DateTime.UtcNow;
        var res = await db.Reservaciones
            .Include(r => r.Seats).ThenInclude(rs => rs.Asiento)
            .FirstOrDefaultAsync(r => r.Id == req.ReservationId);

        if (res is null) return NotFound();
        if (res.Status != ReservationStatus.Held) return BadRequest("Reserva no está en HOLD.");
        if (res.HeldUntil < now) return BadRequest("Reserva expirada.");

        foreach (var rs in res.Seats)
            rs.Asiento.Status = AsientoStatus.Occupied;

        res.Status = ReservationStatus.Confirmed;
        await db.SaveChangesAsync();

        return Ok(new { Ok = true });
    }

    [HttpDelete("{id:guid}")]
    public async Task<IActionResult> Cancel(Guid id)
    {
        var res = await db.Reservaciones
            .Include(r => r.Seats).ThenInclude(rs => rs.Asiento)
            .FirstOrDefaultAsync(r => r.Id == id);
        if (res is null) return NotFound();

        foreach (var rs in res.Seats)
            if (rs.Asiento.Status == AsientoStatus.Held)
                rs.Asiento.Status = AsientoStatus.Free;

        res.Status = ReservationStatus.Canceled;
        await db.SaveChangesAsync();
        return Ok(new { Ok = true });
    }
}
