﻿namespace Reserva.API.Entities
{
    public class Sector
    {
        public Guid Id { get; set; }

        public Guid EventId { get; set; }       
        public Evento Evento { get; set; } = default!;

        public string Name { get; set; } = default!;
        public decimal Price { get; set; }

        public ICollection<Asiento> Seats { get; set; } = new List<Asiento>();
    }
}
