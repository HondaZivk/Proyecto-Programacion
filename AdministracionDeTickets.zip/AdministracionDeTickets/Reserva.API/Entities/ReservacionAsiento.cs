﻿namespace Reserva.API.Entities
{
    public class ReservacionAsiento
    {
        public Guid Id { get; set; }

        public Guid ReservacionId { get; set; }
        public Reservacion Reservacion { get; set; } = default!;

        public Guid AsientoId { get; set; }
        public Asiento Asiento { get; set; } = default!;
    }
}
