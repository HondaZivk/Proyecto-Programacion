﻿namespace Reserva.API.Entities
{
    public class Evento
    {
        public Guid Id { get; set; }
        public string Name { get; set; } = default!;
        public string Venue { get; set; } = default!;
        public DateTime StartsAt { get; set; }

        public ICollection<Sector> Sectors { get; set; } = new List<Sector>();
        public ICollection<Reservacion> Reservaciones { get; set; } = new List<Reservacion>();
    }
}
