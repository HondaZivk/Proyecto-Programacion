﻿namespace Reserva.API.Entities
{
    public class Asiento
    {
        public Guid Id { get; set; }

        public Guid SectorId { get; set; }       // <-- SOLO ESTE FK
        public Sector Sector { get; set; } = default!;

        public string Label { get; set; } = default!;
        public AsientoStatus Status { get; set; } = AsientoStatus.Free;
        public byte[] RowVersion { get; set; } = default!;
    }
    public enum AsientoStatus { Free = 0, Held = 1, Occupied = 2 }
}
