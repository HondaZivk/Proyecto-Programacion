﻿using Microsoft.Extensions.Logging;

namespace Reserva.API.Entities
{
    public class Reservacion
    {
        public Guid Id { get; set; }

        public Guid EventId { get; set; }        // <-- SOLO ESTE FK
        public Evento Evento { get; set; } = default!;

        public string SectorName { get; set; } = default!;
        public decimal UnitPrice { get; set; }
        public string SessionKey { get; set; } = default!;
        public DateTime HeldUntil { get; set; }
        public ReservationStatus Status { get; set; } = ReservationStatus.Held;

        public ICollection<ReservacionAsiento> Seats { get; set; } = new List<ReservacionAsiento>();
    }
    public enum ReservationStatus { Held = 0, Confirmed = 1, Canceled = 2 }


}
