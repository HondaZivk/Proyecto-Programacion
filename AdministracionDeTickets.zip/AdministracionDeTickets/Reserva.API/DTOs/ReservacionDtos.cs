﻿namespace Reserva.API.DTOs
{
    public class ReservacionDtos
    {
        public record HoldRequest(Guid EventId, string Sector, decimal UnitPrice, string SessionKey, List<string> Labels);
        public record HoldResponse(Guid ReservationId, List<string> Held, List<string> Failed);
        public record ConfirmRequest(Guid ReservationId);

    }
}
