using AdministracionDeTickets.BW.CU;
using AdministracionDeTickets.BW.Interfaces.BW;
using AdministracionDeTickets.BW.Interfaces.DA;
using AdministracionDeTickets.DA.Acciones;
using AdministracionDeTickets.DA.Config;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Cors;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAngularDevClient",
        policy =>
        {
        policy.WithOrigins("http://localhost:8100")  // nuevo
                  .AllowAnyHeader()
                  .AllowAnyMethod();
        });
});

builder.Services.AddTransient<IGestionDeConciertoBW,GestionConciertoBW>();
builder.Services.AddTransient<IGestionDeConciertoDA, GestionConciertoDA>();
builder.Services.AddTransient<IGestionDeRolesBW, GestionDeRolesBW>();
builder.Services.AddTransient<IGestionDeRolesDA, GestionDeRolesDA>();

builder.Services.AddDbContext<GestionDeConciertoContext>(options =>
options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}


app.UseHttpsRedirection();

app.UseCors("AllowAngularDevClient");//nuevo

app.UseAuthorization();

app.MapControllers();

app.Run();
