﻿using AdministracionDeTickets.BC.Modelos;
using AdministracionDeTickets.BW.CU;
using AdministracionDeTickets.BW.Interfaces.BW;
using Microsoft.AspNetCore.Mvc;

namespace AdministracionDeTickets.API.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class UsuarioController : Controller
    {

        private readonly IGestionDeRolesBW GestionDeRolesBW;

        public UsuarioController(IGestionDeRolesBW GestionDeRolesBW)
        {
            this.GestionDeRolesBW = GestionDeRolesBW;

        }

        [HttpGet("login")]
        public async Task<ActionResult<Usuario>> GetUsuarioPorCredenciales([FromQuery] string correo, [FromQuery] string contrasenia)
        {
            try
            {
                var usuario = await GestionDeRolesBW.obtenerUsuarioPorCredenciales(correo, contrasenia);
                if (usuario == null)
                    return NotFound("Usuario no encontrado o credenciales incorrectas");

                return Ok(usuario);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error interno del servidor: {ex.Message}");
            }
        }


        [HttpGet("existeCorreo")]
        public async Task<ActionResult<bool>> ExisteCorreo([FromQuery] string correo)
        {
            try
            {
                var existe = await GestionDeRolesBW.existeCorreo(correo);
                return Ok(existe);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error interno del servidor: {ex.Message}");
            }
        }

        [HttpPost(Name = "RegistrarUsuario")]
        public async Task<ActionResult<bool>> Post([FromBody] Usuario usuario)
        {
            try
            {
               
                return Ok(await GestionDeRolesBW.registrarUsuario(usuario));
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error interno del servidor: {ex.Message}");
            }
        }

    }



    
}
