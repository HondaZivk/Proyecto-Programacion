﻿using AdministracionDeTickets.BC.Modelos;
using AdministracionDeTickets.BW.CU;
using AdministracionDeTickets.BW.Interfaces.BW;
using AdministracionDeTickets.DA.Entidades;
using Microsoft.AspNetCore.Mvc;

namespace AdministracionDeTickets.API.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class ConciertoController : Controller
    {
        private readonly IGestionDeConciertoBW gestionDeConciertoBW;
        public ConciertoController(IGestionDeConciertoBW gestionDeConciertoBW)
        {
            this.gestionDeConciertoBW = gestionDeConciertoBW;
        }


        [HttpGet(Name = "GetConciertos")]
        public async Task<ActionResult<List<ResultadoFiltroConcierto>>> ListarConciertos(
          [FromQuery] DateTime? fecha,
          [FromQuery] string? lugar,
          [FromQuery] string? categoriaAsiento,
          [FromQuery] string? promotor)
        {
            try
            {
                var conciertos = await gestionDeConciertoBW.obtenerConciertos(fecha, lugar, categoriaAsiento, promotor);
                return Ok(conciertos);

            }catch (Exception ex)
            {
                return StatusCode(500, $"Error interno del servidor {ex.Message}");
            }
        }


        [HttpGet("ConciertosPromotor")]
        public async Task<ActionResult<List<ResultadoFiltroConcierto>>>obtenerCociertosPromotor (string correoPromotor)
        {
            try
            {
                var conciertosPromotor = await gestionDeConciertoBW.obtenerCociertosPromotor(correoPromotor);
                return Ok(conciertosPromotor);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error interno del servidor: {ex.Message}");
            }
        }




        [HttpPost(Name = "RegistrarConcierto")]

        public async Task<ActionResult<bool>> Post([FromBody]SolicitudConcierto solicitudConcierto)
        {
            try
            {
                return Ok(await gestionDeConciertoBW.registrarConcierto(solicitudConcierto.concierto, solicitudConcierto.categoriasAsiento, solicitudConcierto.media)); 
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error interno del servidor {ex.Message}");
            }
        }



        [HttpPut("{id}",Name ="ActulizarConcierto")]

        public async Task<ActionResult<bool>> Put(int id, [FromBody] SolicitudConcierto solicitudConcierto)
        {
            try
            {
                if(id != solicitudConcierto.concierto.Id)
                {
                    return BadRequest("El id del Concierto no conicide");
                }
                var resultado = await gestionDeConciertoBW.actulizarConcierto(id, solicitudConcierto.concierto, solicitudConcierto.categoriasAsiento, solicitudConcierto.media);

                if (!resultado)
                    return NotFound("Concierto no encotrado");
                return Ok(true);
                
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error interno del servidor: {ex.Message} | Inner: {ex.InnerException?.Message}");
            } 
            
        }



        [HttpDelete("{id}", Name = "EliminarConcierto")]  // falta de hacer, siguiendo lo solicitado en el enunciado.

        public async Task<ActionResult<bool>> Delete(int id)
        {
           try 
            { 
            var resultado=await gestionDeConciertoBW.eliminarConcierto(id);
                if(!resultado)
                    return NotFound("Concierto no encotrado");
                return Ok(true);

            } catch (Exception ex)
            {
                return StatusCode(500, $"Error interno del servidor {ex.Message}");
            }
        }

    }

    
}
