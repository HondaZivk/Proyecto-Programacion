﻿


namespace AdministracionDeTickets.BC.Modelos
{
    public class Concierto
    {
        public int Id { get; set; }
        public string? Nombre { get; set; }
        public string Descripcion { get; set; }
        public DateTime FechaHora { get; set; }
        public string? Lugar { get; set; }
        public int Capacidad { get; set; }
        public Boolean InicioDeVenta { get; set; }
        public string? Promotor { get; set; }

       // public Boolean AsientosComprados { get; set; }  Descomentarlo cuando este listo el modulo 3

    
    }
}
