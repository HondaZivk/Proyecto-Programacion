﻿

namespace AdministracionDeTickets.BC.Modelos
{
    public class Usuario
    {
     public string Correo { set ; get; }

     public string Contrasenia { set; get; }

     public string Nombre { set; get; } 

     public string ? Rol { set; get; }
    }
}
