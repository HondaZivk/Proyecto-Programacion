﻿

namespace AdministracionDeTickets.BC.Modelos
{
    public class MediaPromocional
    {
        public int? Id { get; set; }
        public string FotoVideoUrl { get; set; }

        public int IdConcierto { get; set; }


    }
}
