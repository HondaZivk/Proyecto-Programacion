﻿

namespace AdministracionDeTickets.BC.Modelos
{
    public class CategoriaAsiento
    {   public int? Id { get; set; }
        public string Nombre { get; set; }

        public int Numero { get; set; }

        public decimal Precio { get; set; }

        public int IdConcierto { get; set; }


       


    }
}
