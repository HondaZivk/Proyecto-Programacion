﻿

namespace AdministracionDeTickets.BC.Modelos
{
    public class ResultadoFiltroConcierto
    {
        public Concierto Concierto { get; set; }
        public List<CategoriaAsiento>? CategoriaAsientos { get; set; }

        public List<MediaPromocional> MediaPromocional { get; set; }
    }
}
