﻿

namespace AdministracionDeTickets.BC.Modelos
{
    public class SolicitudConcierto
    {
        public Concierto concierto { get; set; }
        public List<CategoriaAsiento>? categoriasAsiento { get; set; }
        public List<MediaPromocional> media { get; set; }

    }
}
