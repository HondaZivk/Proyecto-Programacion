﻿

using AdministracionDeTickets.BC.Modelos;
using System.Text.RegularExpressions;

namespace AdministracionDeTickets.BC.ReglasDeNegocio
{
    public class ReglasDeUsuarios
    {
        public static bool elUsuarioEsValido(Usuario usuarios)
        {
            return usuarios != null &&
                ElNombreEsValido(usuarios.Nombre) &&
                elCorreoEsValido(usuarios.Correo) &&
                LaContraseniaEsSegura(usuarios.Contrasenia);
        }

        public static bool elCorreoEsValido(string correo)
        {
            if (string.IsNullOrWhiteSpace(correo))
                return false;

            string patron = @"^[^@\s]+@[^@\s]+\.[^@\s]+$";
            return Regex.IsMatch(correo, patron, RegexOptions.IgnoreCase);
        }

        public static bool LaContraseniaEsSegura(string contrasenia)
        {
            if (string.IsNullOrWhiteSpace(contrasenia) || contrasenia.Length < 8)
                return false;

            return Regex.IsMatch(contrasenia, @"^(?=.*[A-Z])(?=.*\d)(?=.*[^\w\d\s]).+$");
        }

        public static bool ElNombreEsValido(string nombre)
        {
            return !string.IsNullOrWhiteSpace(nombre);
        }
    }
}
