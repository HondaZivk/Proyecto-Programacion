﻿

using AdministracionDeTickets.BC.Modelos;
using System.Reflection.Metadata.Ecma335;

namespace AdministracionDeTickets.BC.ReglasDeNegocio
{
    public class ReglasDeConcierto
    {
           public static bool elConciertoEsValido(Concierto concierto, List<CategoriaAsiento> categoriasAsiento, List<MediaPromocional> media)
        {
            return concierto != null &&
                categoriasAsiento != null &&
                media != null &&
                !string.IsNullOrEmpty(concierto.Nombre) &&
                !string.IsNullOrEmpty(concierto.Descripcion) &&
                !string.IsNullOrEmpty(concierto.Lugar) &&
                concierto.Nombre.Length >= 5 &&
                concierto.Nombre.Length <= 100 &&
                concierto.Descripcion.Length >= 50 &&
                concierto.FechaHora > DateTime.Now &&
                concierto.Capacidad > 0;
            
        }

        public static bool actualizarConciertoEsValido(Concierto concierto,  List<MediaPromocional> media)
        {
            return concierto != null &&
                media != null &&
                !string.IsNullOrEmpty(concierto.Descripcion) &&
                concierto.Descripcion.Length >= 50;
        }

   

        public static bool elIdEsValido(int id)
        {
            return id > 0;
        }
    }
}
